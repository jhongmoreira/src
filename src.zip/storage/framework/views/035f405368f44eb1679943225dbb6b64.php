<?php $__env->startSection('title','Novo Cliente - Exata TI'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12"><h3>Editando <?php echo e($cliente->nome); ?></h3></div>
</div>

<form action="<?php echo e(route('update-cliente', $cliente->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

<div class="row">

    <div class="col-md-8">
        <div class="form-group">
          <label for="nome">Nome</label>
          <input type="text" name="nome" id="nome" class="form-control" value="<?php echo e($cliente->nome); ?>">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="cpf">CPF</label>
          <input type="number" name="cpf" id="cpf" class="form-control" value="<?php echo e($cliente->cpf); ?>">
        </div>
    </div>

</div>    

<div class="row">

    <div class="col-md-4">
        <div class="form-group">
          <label for="whatsapp">Whatsapp</label>
          <input type="number" name="whatsapp" id="whatsapp" class="form-control" value="<?php echo e($cliente->whatsapp); ?>">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" name="email" id="email" class="form-control" value="<?php echo e($cliente->email); ?>">
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="pasta">Pasta do Drive</label>
          <input type="url" name="pasta" id="pasta" class="form-control" value="<?php echo e($cliente->pasta); ?>">
        </div>
    </div>

</div>   

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
                <label for="obs">Observação</label>
                <textarea name="obs" id="obs" rows="10" class="form-control"><?php echo e($cliente->obs); ?></textarea>
        </div>
    </div>
</div>     

<div class="row">
    <div class="col-md-3">
        <button class="form-control btn btn-warning" type="submit">Atualizar</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\src\resources\views/cliente/edit.blade.php ENDPATH**/ ?>