<?php $__env->startSection('title','Clientes - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12" id="relatorio">
        

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="row">
                        <div class="col-md-5">
                            <h3 class="mb-0 text-gray-800">Relatório de Atendimentos</h3>
                        </div>

                        <div class="col-md-7 d-flex justify-content-end">
                                    <button class="btn btn-sm btn-primary mr-1" data-toggle="modal" data-target="#exampleModal" >Filtrar</button>
                                    <!-- Modal -->
                                    <form action="<?php echo e(route('relatorio-periodos')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">

                                                <div class="form-group">
                                                    <label for="start_date">Data Inicial:</label>
                                                    <input type="date" id="start_date" name="start_date" required class="form-control">
                                                </div>

                                                <div class="form-group">
                                                    <label for="end_date">Data Final:</label>
                                                    <input type="date" id="end_date" name="end_date" required class="form-control">
                                                </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-secondary">Confirmar</button>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                    <a href="#"  onclick="Convert_HTML_To_PDF();" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Baixar</a>
                        </div>

                    <!-- </div>  -->
                </div>
                
                
            </div>



                <div class="table-responsive p-2">
                    <table width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Cod.</th>
                                <th>Nome</th>
                                <th>Data</th>
                                <th>Hora</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>Cod.</th>
                                <th>Nome</th>
                                <th>Data</th>
                                <th>Hora</th>
                                <th>Status</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $atendimentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atendimento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($atendimento->id); ?></td>
                                <td> <?php echo e($atendimento->cliente->nome); ?> </td>
                                <td><?php echo e(date('d/m/Y', strtotime($atendimento->data_cadastro))); ?></td>
                                <td><?php echo e(date('H:m', strtotime($atendimento->hora_cadastro))); ?></td>
                                <td>
                                    <?php if($atendimento->finalizado == 0): ?>
                                        <span class="badge badge-danger">Não Iniciado</span>
                                    <?php elseif($atendimento->finalizado == 1): ?>
                                        <span class="badge badge-warning">Em Andamento</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Concluído</span>                                    
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
                </div>

</div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\src\resources\views/relatorio/index.blade.php ENDPATH**/ ?>