<?php $__env->startSection('title','Novo Cliente - Exata TI'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12"><h3>Nova Ordem</h3></div>
</div>

<form action="<?php echo e(route('salvar-ordem')); ?>" method="post">
    <?php echo csrf_field(); ?>

<div class="row">

    <div class="col-md-6">
        <div class="form-group">
            <label for="cliente_id">Cliente</label>
            <select name="cliente_id" id="cliente_id" class="form-control" required>
                <option value=""></option>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nome); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
          <label for="data_cadastro">Data</label>
          <input type="date" name="data_cadastro" id="data_cadastro" class="form-control">
        </div>
    </div>

    <div class="col-md-3">
        <div class="form-group">
          <label for="finalizado">Status</label>
            <select name="finalizado" id="finalizado" class="form-control" required>
                <option value=""></option>
                <option value="0">Em Andamento</option>
                <option value="1">Finalizado</option>
            </select>
        </div>
    </div>

</div>   
 

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
                <label for="descricao">Observação</label>
                <textarea name="descricao" id="descricao" rows="10" class="form-control"></textarea>
        </div>
    </div>
</div>     

<div class="row">
    <div class="col-md-3">
        <button class="form-control btn btn-primary" type="submit">Cadastrar</button>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/ordem/create.blade.php ENDPATH**/ ?>