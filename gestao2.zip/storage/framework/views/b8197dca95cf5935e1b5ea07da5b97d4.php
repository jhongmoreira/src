<?php $__env->startSection('title','Detalhe do Cliente - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12"><h3><?php echo e($cliente->nome); ?></h3></div>
</div>

<div class="row">

    <div class="col-md-4">
        <div class="form-group">
          <label for="cpf"><b>CPF</b></label>
          <p><?php echo e($cliente->cpf); ?></p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="whatsapp"><b>WhatsApp</b></label>
          <div>
              <a href="https://wa.me/<?php echo e($cliente->whatsapp); ?>" target="_blank"><?php echo e($cliente->whatsapp); ?> <i class="fa fa-link"></i></a>
          </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="email"><b>E-mail</b></label>
          <p><?php echo e($cliente->email); ?></p>
        </div>
    </div>

</div>

<hr>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label for="obs"><b>Observação</b></label>
            <p><?php echo e($cliente->obs); ?></p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gestao2\resources\views/cliente/show.blade.php ENDPATH**/ ?>