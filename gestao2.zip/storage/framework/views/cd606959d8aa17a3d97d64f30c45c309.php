<?php $__env->startSection('title','Detalhe do Cliente - Exata TI'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12"><h3><?php echo e($cliente->nome); ?></h3></div>
</div>

<div class="row">

    <div class="col-md-4">
        <div class="form-group">
          <label for="cpf"><b>RA/Matrícula</b></label>
          <p><?php echo e($cliente->matricula); ?></p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="whatsapp"><b>WhatsApp</b></label>
          <div>
              <a href="https://wa.me/+55<?php echo e($cliente->whatsapp); ?>" target="_blank"><?php echo e($cliente->whatsapp); ?> <i class="fa fa-link"></i></a>
          </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
          <label for="email"><b>E-mail</b></label>
          <p><?php echo e($cliente->email); ?></p>
        </div>
    </div>

</div>

<hr>

<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <label for="obs"><b>Observação</b></label>
            <p><?php echo e($cliente->obs); ?></p>
        </div>
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-12">

        <div class="card shadow mb-4">
        <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    Atendimentos
                </h6>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Descricação</th>
                                <th>Data</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>ID</th>
                                <th>Descricação</th>
                                <th>Data</th>
                                <th>Ação</th>
                            </tr>
                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $cliente->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->descricao); ?></td>
                                <td><?php echo e(date('d/m/Y', strtotime($order->data_cadastro))); ?></td>
                                <td>
                                    <a href="<?php echo e(route('editar-ordem', $order->id)); ?>" class="btn btn-sm btn-warning mt-1"><i class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('apagar-ordem', $order->id)); ?>" class="btn btn-sm btn-danger mt-1"><i class="fa fa-ban"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
                </div>
            </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestao2\resources\views/cliente/show.blade.php ENDPATH**/ ?>